//
//  DataManager.swift
//  Covid19 Spritle
//
//  Created by Padmasri Nishanth on 1/12/21.
//

import Foundation

// Protocol Declaration 
protocol Covid19DataManagerDelegate{
    func didUpdateUIAfterFetchingDataSuccesful(with stateWiseData : StatesData)
}

struct DataManager {
    
    //Declaring the Delegate for the Using it in VC
    var delegate : Covid19DataManagerDelegate?
    
    // URL of the Api
    let url : String =  "https://api.covid19india.org/data.json"
    
    func fetchData(){
        loadData(with: url)
    }
    
    // Func to load the Data with the API using URL Session DataTask
    func loadData(with url : String){
        if let url = URL(string: url){
            let session = URLSession(configuration: .default)
            let dataTask = session.dataTask(with: url) { (data, response, error) in
                if let _ = error{
                    print("Error")
                    return
                }
                if let data = data{
                    if let statesData = self.parseJSON(with: data){
                        DispatchQueue.main.async {
                            self.delegate?.didUpdateUIAfterFetchingDataSuccesful(with: statesData)
                        }
                    }
                }
            }
            //Resuming the DataTask
            dataTask.resume()
        }
    }
    
    // Func To parse the JSONData with the JSON Decoder
    func parseJSON(with data : Data) -> StatesData?{
        let decoder = JSONDecoder()
        do {
            let statesData =  try decoder.decode(StatesData.self, from: data)
            return statesData
          
        }
        catch {
            print(error)
            return nil
        }
    }
}
