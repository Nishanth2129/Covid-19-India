//
//  StatesData.swift
//  Covid19 Spritle
//
//  Created by Padmasri Nishanth on 1/12/21.
//

import Foundation

// Structuring the Data Acc to the API
struct StatesData : Decodable {
    let statewise : [SingleStateData]
}

// Structuring the Data Acc to StateWise With API
struct SingleStateData : Decodable {
    let active : String
    let confirmed : String
    let state : String
    let deaths : String
    let recovered : String
    let lastupdatedtime : String
}
