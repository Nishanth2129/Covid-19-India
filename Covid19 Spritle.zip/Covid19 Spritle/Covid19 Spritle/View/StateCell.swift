//
//  StateCell.swift
//  Covid19 Spritle
//
//  Created by Padmasri Nishanth on 1/12/21.
//

import UIKit

class StateCell: UITableViewCell {
    
    @IBOutlet weak var stateLabel: UILabel!
    @IBOutlet weak var recoveredLabel: UILabel!
    @IBOutlet weak var confirmedLabel: UILabel!
    @IBOutlet weak var activeLabel: UILabel!
    @IBOutlet weak var deathLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
