//
//  IndiaWiseViewController.swift
//  Covid19 Spritle
//
//  Created by Padmasri Nishanth on 1/12/21.
//

import UIKit

class IndiaWiseViewController: UIViewController, Covid19DataManagerDelegate{
    
    @IBOutlet weak var confirmed: UILabel!
    @IBOutlet weak var recovered: UILabel!
    @IBOutlet weak var active: UILabel!
    @IBOutlet weak var deaths: UILabel!
    
    var dataManager = DataManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        dataManager.delegate = self
        dataManager.fetchData()
    }
    
    func didUpdateUIAfterFetchingDataSuccesful(with stateWiseData: StatesData) {
        let totalItem = stateWiseData.statewise[0]
        confirmed.text = totalItem.confirmed
        recovered.text = totalItem.recovered
        active.text = totalItem.active
        deaths.text = totalItem.deaths
    }
    
}
